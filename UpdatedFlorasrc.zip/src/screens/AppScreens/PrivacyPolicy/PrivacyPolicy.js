import React, { useEffect, useState } from "react";
import { View, SafeAreaView, ScrollView, Image, Dimensions } from 'react-native';
import styles from "./styles";
import { Size, Colors, Strings, Label, RegularLabel, BoldLabel, ImagePath, Icon } from "../../../constants";
import { BackButtonHeader } from "../../../components";
import { heightPercentageToDP as hp, widthPercentageToDP as wp } from "react-native-responsive-screen";
import Swiper from 'react-native-swiper';
import { instance } from "../../../utils";
import Toast from 'react-native-simple-toast';
import { WebView } from 'react-native-webview';
export default PrivacyPolicy = ({ route, navigation }) => {

    const { width } = Dimensions.get("window")
    const [pageData, setPageData] = useState();
    const [pageTitle, setPageTitle] = useState();
    const [isLoding, setLoding] = useState(false);
    const [webViewHeightNew, setWebViewHeightNew] = useState(50);
    const ratingFlawersData = [
        { id: 1, topTitle: Strings.Home.goodService, },
        { id: 2, topTitle: Strings.Home.goodService },
        { id: 3, topTitle: Strings.Home.goodService },
    ]

    const showToast = (message) => {
        Toast.show(message);
    }

    /*const getPageData = () => {
        setLoding(true)
        instance.post('/get_page_details', {
            req: {
                "data": {"page_url":route.params?.requestPage}
            }
        }).then(async (response) => {
            const userData = JSON.parse(response.data);
            if (userData.status === 'success') {
               
                setPageData(userData?.result)
                setPageTitle(userData?.result?.menu_type_text)
                setLoding(false)

            } else {
                //console.log('response.data error message======', userData.error);
                setLoding(false);
                showToast(userData?.message);
            }
        }).catch(error => {
            //console.log("catch error ===somthing whent wrong", error)
            showToast(Strings.Other.catchError);
        });
    }*/

    useEffect(() => {
        console.log("URL---", 'https://front-dev-bloom.fullestop.io/mobile-cms/' + route.params?.requestPage)
        //  route.params?.requestPage ? getPageData() : '';
    }, []);


    useEffect(() => {
        console.log("webViewHeight==", webViewHeightNew)
    }, [webViewHeightNew]);


    const webViewScript = `
  setTimeout(function() { 
    window.ReactNativeWebView.postMessage(''); 
  }, 10);
`;

    return (
        <SafeAreaView style={styles.mainContainer}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <BackButtonHeader
                    title={pageTitle}
                    containerStyle={{ marginHorizontal: Size.xm1 }}
                />
                {/* <View style={{ marginTop: Size.xs3 }}>
                    <Image source={ImagePath.Other.privacy} style={{ height: hp('20%'), width: wp('100%') }} resizeMode="stretch" />
                </View> */}
                {isLoding ?
                    <Loader />
                    :
                    <>
                        {route.params?.requestPage &&
                            <WebView
                                originWhitelist={['*']}
                                source={{ uri: 'https://front-dev-bloom.fullestop.io/mobile-cms/' + route.params?.requestPage }}
                                style={{ flex: 1, width: wp('100%'), height: webViewHeightNew, backgroundColor: "red", margin: 5 }}
                                javaScriptEnabled={true}
                                domStorageEnabled={true}
                                startInLoadingState={true}
                                scalesPageToFit={true}
                                automaticallyAdjustContentInsets={false}
                                injectedJavaScript='window.ReactNativeWebView.postMessage(document.body.scrollHeight)'
                                onMessage={(event) => {
                                    console.log("Number(event.nativeEvent.data)==", Number(event.nativeEvent.data))
                                    setWebViewHeightNew(Number(event.nativeEvent.data))
                                }}
                            />

                        }



                        {/* <WebView
                    originWhitelist={['*']}
                    source={{ html: "<style>body {max-width: 100%; font-family: sans-serif;overflow-wrap: break-word;word-wrap: break-word; }</style>" +
      "<body>" +pageData?.page_content +
      "</body>"}}
                    style={{width: wp('100%'),height:hp(webViewHeightNew)}}                    
                    automaticallyAdjustContentInsets={false}
                    onMessage={(event)=>{
                        console.log("Number(event.nativeEvent.data)==",Number(event.nativeEvent.data))
                       setWebViewHeightNew(Number(event.nativeEvent.data))
                    }}
                    injectedJavaScript='window.ReactNativeWebView.postMessage(document.body.scrollHeight)'
                    //injectedJavaScript={webViewScript}                   
                  /> */}
                        {/* <WebView
                    originWhitelist={['*']}
                    source={pageData.page_content}
                    style={{ flex: 1 }}
                  /> */}
                    </>
                }
                {/* <View style={{ marginHorizontal: Size.m, }}>
                    <View style={{ marginTop: Size.xl }}>
                        <RegularLabel title={"Last updated 22nd February, 2023."} regularStyle={{}} />
                    </View>
                    <View style={{ marginTop: Size.m011, width: wp('86%') }}>
                        <RegularLabel title={"This privacy notice for UAE Flowers (Company,  we,  us, or  our), describes how and why we might collect, store, use and/or share ( process) your information when you use our services (‘ Services’), such as when you:."} regularStyle={{}} />
                    </View>
                    <View style={{ marginTop: Size.m011, flexDirection: "row" }}>
                        <RegularLabel title={"- Visit our website at"} regularStyle={{}} />
                        <RegularLabel title={" https://www.uaeflowers.com/,"} regularStyle={{ color: Colors.Primary.Camel }} />
                    </View>
                    <RegularLabel title={"   or any of our sister websites."} regularStyle={{}} />
                    <RegularLabel title={"- Engage with us in other related ways, included any"} regularStyle={{}} />
                    <RegularLabel title={"   sales, marketing, or events."} regularStyle={{}} />
                    <View style={{ marginTop: Size.m011 }}>
                        <BoldLabel title={"Questions or concerns?"} boldStyle={{}} />
                    </View>
                    <View style={{ marginTop: Size.m011, width: wp('87%') }}>
                        <RegularLabel title={"Reading this privacy notice will help you understand your privacy rights and choices. If you do not agree with our policies and practices, please do not use our Services. If you still have any questions or concerns, please contact us at"} regularStyle={{}} />
                    </View>
                    <View style={{ borderBottomWidth: 1, borderColor: Colors.Primary.Camel, width: wp('43.2%') }}>
                        <RegularLabel title={"wecare@uaeflowers.com."} regularStyle={{ color: Colors.Primary.Camel, }} />
                    </View>
                    <View style={{ marginTop: Size.m011 }}>
                        <BoldLabel title={"SUMMARY OF KEY POINTS:"} boldStyle={{}} />
                    </View>
                    <RegularLabel title={"This summary provides key points from our privacy notice."} regularStyle={{}} />
                    <View style={{ marginTop: Size.m011 }}>
                        <BoldLabel title={"What personal information do we process?"} boldStyle={{}} />
                    </View>
                    <RegularLabel title={"When you visit, use, or navigate our Services, we may process personal information depending on how you interact with UAE Flowers and the Services, the choices you make, and the products and features you use. Do we process any sensitive personal information? We do not process sensitive personal information. Do we receive any information from third parties? We do not receive any information from third parties. How do we process your information? We process your information to provide, improve, and administer our Services, communicate with you, for security and fraud prevention, and to comply with the law. We may also process your information for other process with your consent. We process your information only when we have a valid legal reason to do so. How do we keep your information safe? We have organizational and technical processes and procedures in place to protect your personal information. However, no electronic transmission over the internet or information storage technology can be guaranteed to be 100% secure, so we cannot promise or guarantee that hackers, cybercriminals, or other unauthorized third parties will not be able to defeat our security and improperly collect, access, steal, or modify your information. What Information Do We Collect? Personal information you disclose to us In Short : We collect personal information that you provide to us. We collect personal information that you voluntarily provide to us when you register on the Services, express an interest in obtaining information about us or our products and Services, when you participate in activities on the Services, or otherwise when you contact us. Personal Information Provided by You. The personal information that we collect depends on the context of your interactions with us and the Services, the choices you make, and the products and features you use. The personal information we collect may include the following: Names Phone Numbers E-mail addresses Birthdays Mailing addresses Usernames Passwords Billing Addresses Names disclosed on the wishing cards The occasions for which you selected our Service *Note, we do not store any financial details. We don’t process sensitive information - card Details."} regularStyle={{}} />
                </View> */}
                <View style={[styles.slideMainContainer, {}]}>
                    <Spacer style={styles.spacerTop} />
                    <Label style={[styles.title, { fontSize: Size.m1 }]} text={Strings.Home.UAEFlowersReviews} />
                    <Spacer style={{ marginTop: Size.m1 }} />

                    <Swiper style={{ height: hp('21%') }}
                        // <Swiper style={{ height: height * 0.21 }}
                        showsPagination={false}
                        scrollEnabled={false}
                        showsButtons
                        // buttonWrapperStyle={styles.wrapperButton}
                        nextButton={
                            <View style={styles.swiperButtonNext} hitSlop={styles.hitSlop}>
                                <Image style={styles.swiperIcon} source={ImagePath.Home.arrowNext} />
                            </View>
                        }
                        prevButton={
                            <View style={styles.swiperButtonBack} hitSlop={styles.hitSlop}>
                                <Image style={styles.swiperIcon} source={ImagePath.Home.arrowBack} />
                            </View>}
                    >

                        {ratingFlawersData.map((item) => {
                            return (
                                <View
                                    key={item.id}
                                    style={styles.sliderContainer}>
                                    <Label style={styles.sliderTopTitle} text={item.topTitle} />
                                    <View style={{ marginVertical: Size.xs2 }}>
                                        <Icon style={styles.sliderRatingIcon} source={ImagePath.Home.ratingStar} />
                                    </View>
                                    <Label style={{ fontSize: Size.m0, }} text={Strings.Home.boughtFlowers} />

                                    <Spacer />
                                    <RowColumn
                                        titleStyle={{ marginLeft: 0 }}
                                        labelStyle={styles.sliderBuyerName}
                                        labelStyle1={styles.sliderOderOn}
                                        title={Strings.Home.buyerName}
                                        title1='Terry Shirley'
                                    />
                                    <RowColumn
                                        titleStyle={{ marginLeft: 0 }}
                                        labelStyle={styles.sliderBuyerName}
                                        labelStyle1={styles.sliderOderOn}
                                        title={Strings.Home.orderOn}
                                        title1='12 Feb, 2023'
                                    />
                                </View>
                            );
                        })
                        }
                    </Swiper>
                </View>
            </ScrollView>
        </SafeAreaView >
    )
}
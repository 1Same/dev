export default GlobalConstant = {
    allowedFileTypes: ['png', 'jpg', 'webp', 'gif'],
}

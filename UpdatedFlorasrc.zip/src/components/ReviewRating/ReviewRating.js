import React, { useState, useEffect, memo } from "react";
import { View, Image, Platform } from 'react-native'
import Swiper from "react-native-swiper";
import styles from "./styles";
import RowColumn from "../RowColumn/RowColumn";
import { RegularLabel, ImagePath, Label, RobotoBoldLabel, Colors, Strings, } from "../../constants";
import { instance } from "../../utils";
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { dateFormat } from "../../lib";
import { AlertError } from "../ToastNotification/ToastNotification";

const ReviewRating = (props) => {

    const [reviewData, setReviewData] = useState([]);
    const { sliderManView, sliderView, productId = '', showTitle = false,reviewStyles } = props;

    const ReviewListData = () => {
        instance.post('/review_list', {
            req: { "data": {} }
        }).then(async (response) => {
            const userData = JSON.parse(response.data);
            if (userData.status === 'success') {
                setReviewData(userData?.result)
            }
        }).catch(error => {
            console.log("ReviewListData======catch======", error);
            AlertError(Strings.Other.catchError);
        });
    };

    const renderStars = (rating) => {
        const starImages = [];
        const totalStars = 5;

        for (let i = 1; i <= totalStars; i++) {
            const starType =
                i <= rating
                    ? ImagePath.Other.singleStar
                    : i === Math.round(rating) && rating % 1 !== 0
                        ? ImagePath.Other.halfStar
                        : ImagePath.Other.emptyStar;

            starImages.push(
                <View key={i} style={{ marginHorizontal: 1 }}>
                    <Image source={starType} style={styles.starIcon} />
                </View>
            );
        }
        return starImages;
    };

    useEffect(() => {
        ReviewListData()
    }, [])

    return (
        <View style={[{
            backgroundColor: Colors.FantasyNew,
            marginTop: hp('4%'),
            height: hp('38%'),
        }, sliderManView]}>
            <Spacer style={styles.spacerTop} />

            {showTitle && <View style={{ marginLeft: 18 }}>
                <RobotoBoldLabel robotoBoldStyle={[styles.title, { fontSize: 16 }]} title={Strings.Home.flowersReviews} />
            </View>}

            <View style={[styles.slideMainContainer, sliderView]}>
                {reviewData?.length > 0 &&
                    <Swiper
                        showsPagination={false}
                        scrollEnabled={false}
                        showsButtons={true}
                        loop={true}
                        nextButton={
                            <View style={{ left: 25, marginBottom: Platform.OS == 'ios' ? wp('36%') : wp('27%'), }}>
                                <Image style={{ width: 32, height: 32, }} source={ImagePath.Other.arrowNext} />
                            </View>
                        }
                        prevButton={
                            <View style={{ right: 25, marginBottom: Platform.OS == 'ios' ? wp('36%') : wp('27%') }}>
                                <Image style={{ width: 32, height: 32, }} source={ImagePath.Other.arrowBack} />
                            </View>
                        }
                    >
                        {reviewData?.map((item) => {
                            return (
                                <View key={item._id} style={[styles.sliderContainer,reviewStyles]}>
                                    <Label style={styles.sliderTopTitle} text={item.title} />

                                    <View style={{ flexDirection: "row", marginTop: 8, }}>
                                        {renderStars(item.rating)}
                                    </View>
                                    <View style={{ height: 48, marginTop: 8 }}>
                                        <RegularLabel
                                            numberOfLines={2}
                                            ellipsizeMode={'tail'}
                                            regularStyle={{ fontSize: 13, }}
                                            title={item.review}
                                        />
                                    </View>
                                    <Spacer />
                                    <RowColumn
                                        titleStyle={{ marginLeft: 0, }}
                                        labelStyle={styles.sliderBuyerName}
                                        labelStyle1={styles.sliderOderOn}
                                        title={Strings.Home.buyerName}
                                        title1={item.full_name}
                                    />
                                    <View style={{ marginTop: 5, }}>
                                        <RowColumn
                                            titleStyle={{ marginLeft: 0 }}
                                            labelStyle={styles.sliderBuyerName}
                                            labelStyle1={styles.sliderOderOn}
                                            title={Strings.Home.orderOn}
                                            title1={dateFormat(item?.created, 'DD MMM, yyyy')}
                                        />
                                    </View>
                                </View>
                            );
                        })
                        }
                    </Swiper>
                }
            </View>
        </View>
    )
}
export default memo(ReviewRating)
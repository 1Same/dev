import React, { memo } from "react";
import { View, Image } from 'react-native';

import { Size, Label } from "../../constants";

import Styles from "../../screens/AppScreens/Home/styles";




const ListRenderItem = (props) => {

    const { icon, title, price, style, dealsAdd, topTitle } = props;

    return (
        <View>
            <View style={[Styles.swiperArrivals, Styles.swiperArrivals2, style]}>
                <View style={{ flex: 1, }}>
                    <Image style={Styles.horizontalListIcon} source={icon} resizeMode="stretch" />
                </View>
                <View style={{ alignItems: 'center', bottom: Size.xm }}>
                    <Label style={[Styles.listTitle, topTitle]} text={title} />
                    {price ? <View style={{ marginTop: Size.xxs + 2 }}>
                        <Label style={Styles.priceTitle} text={price} />
                    </View> : null}
                </View>
            </View>

            {dealsAdd ? <View style={Styles.dealsButtonContainer}>
                <Label style={Styles.deals} text='Spl.Deals' />
            </View> : null}

        </View>
    )
}
export default memo(ListRenderItem);
import React, { memo } from "react";
import { View } from "react-native";
import { Colors, Label } from "../../constants";

const GetResponseMessage = ({ message }) => {
    return (
        <View style={{ marginLeft: 19 }}>
            <Label style={[{ color: Colors.Black, fontSize: 13.5 }]} text={message} />
        </View>
    )
}
export default memo(GetResponseMessage);
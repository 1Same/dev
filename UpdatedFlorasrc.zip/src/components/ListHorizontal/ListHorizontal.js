import React, { memo } from "react";
import { View, StyleSheet, TouchableOpacity, Text } from 'react-native';
import { Colors, Label, Typography, ImagePath, Icon } from "../../constants";
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { ProgressiveImage, RowColumn } from "../../components";
import SkeletonPlaceholder from "react-native-skeleton-placeholder";

const ListHorizontal = (props) => {

    const {
        onPress,
        icon,
        regularText,
        price,
        style,
        iconStyle,
        disabled,
        regularTextStyle,
        boldTextStyle,
        rating,
        numberOfLines,
        ellipsizeMode,
        isLoading,
        reviews,
        delivery_frequency
    } = props;


    return (
        <>
            {isLoading ?
                <SkeletonPlaceholder>
                    <SkeletonPlaceholder.Item
                        style={styles.mainContainerBoder}
                        height={320}
                        width={wp('47.5%')}
                        margin={10} />
                </SkeletonPlaceholder>
                :
                <TouchableOpacity onPress={onPress} activeOpacity={0.7} disabled={disabled}>
                    {icon &&
                        // <ProgressiveImage
                        //     style={[styles.icon, iconStyle]}
                        //     source={icon}
                        //     resizeMode="contain"
                        // />
                        <Icon
                            style={[styles.icon, iconStyle]}
                            source={icon}
                            resizeMode="contain"
                        />

                    }

                    {regularText || price ?
                        <View style={[styles.flowersCon, style]}>

                            {regularText &&
                                <Label style={[styles.regularText, regularTextStyle]}
                                    numberOfLines={numberOfLines}
                                    ellipsizeMode={ellipsizeMode}
                                    text={regularText}
                                />}
                            {price && <Label style={[styles.boldText, boldTextStyle]} text={price} />}

                            <View style={styles.RowColumn}>
                                <Label style={[styles.deliveryText, { fontSize: 15 }]} text={rating} />
                                <Icon style={{ width: 17, height: 17, marginLeft: 5 }} source={ImagePath.Other.singleStar} />
                                <Label style={[styles.deliveryText, { fontSize: 15, marginLeft: 12 }]} text={reviews} />
                            </View>

                            {delivery_frequency &&
                                <View style={{ marginTop: 8 }}>
                                    <Text style={styles.deliveryText}>{`Earliest Delivery:`}<Text style={styles.deliveryFrequency}>{delivery_frequency}</Text></Text>
                                </View>}
                        </View> : null
                    }
                </TouchableOpacity>
            }
        </>
    )
}
export default memo(ListHorizontal)

const styles = StyleSheet.create({
    icon: {
        width: wp('47%'),
        height: wp('42%'),
        borderTopRightRadius: 11,
        borderBottomLeftRadius: 11,
    },
    flowersCon: {
        marginVertical: 15,
        marginHorizontal: 10,
    },
    mainContainerBoder: {
        borderWidth: 1,
        borderColor: Colors.Camel,
        borderTopRightRadius: 12,
        borderBottomLeftRadius: 12
    },
    boldText: {
        fontSize: 14,
        color: Colors.Black,
        fontFamily: Typography.RobotoBold,
        marginVertical: 8
    },
    regularText: {
        fontSize: 15,
        color: Colors.Dune,
        fontFamily: Typography.LatoBold
    },
    deliveryText: {
        fontSize: 13,
        color: Colors.Black,
        fontFamily: Typography.LatoMedium
    },
    deliveryFrequency: {
        fontSize: 13,
        color: Colors.Red,
        fontFamily: Typography.LatoBold
    },
    RowColumn: {
        flexDirection: 'row',
        alignItems: 'center'
    }
})
